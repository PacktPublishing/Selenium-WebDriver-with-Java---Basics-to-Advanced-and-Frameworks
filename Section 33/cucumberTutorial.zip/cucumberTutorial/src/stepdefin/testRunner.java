package stepdefin;

import org.junit.runner.RunWith;

import cucumber.api.java.it.Date;
import cucumber.api.junit.Cucumber;

// runner class

@RunWith(Cucumber.class)
@Cucumber.Options(format={"html:output"})
public class testRunner {
	
	
	
	
	
}
